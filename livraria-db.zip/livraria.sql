-- Criação das tabelas
CREATE TABLE livros (
    id INT PRIMARY KEY,
    titulo VARCHAR(100),
    autor VARCHAR(100),
    preco DECIMAL(10,2),
    estoque INT
);

CREATE TABLE pedidos (
    id INT PRIMARY KEY,
    data_pedido DATE,
    livro_id INT,
    quantidade INT,
    FOREIGN KEY (livro_id) REFERENCES livros(id)
);

-- Inserção de dados na tabela livros
INSERT INTO livros (id, titulo, autor, preco, estoque) VALUES
(1, 'Dom Casmurro', 'Machado de Assis', 29.90, 10),
(2, 'O Pequeno Príncipe', 'Antoine de Saint-Exupéry', 19.90, 15),
(3, '1984', 'George Orwell', 34.50, 5);

-- Inserção de dados na tabela pedidos
INSERT INTO pedidos (id, data_pedido, livro_id, quantidade) VALUES
(1, '2025-06-01', 1, 2),
(2, '2025-06-02', 3, 1),
(3, '2025-06-03', 2, 4);
